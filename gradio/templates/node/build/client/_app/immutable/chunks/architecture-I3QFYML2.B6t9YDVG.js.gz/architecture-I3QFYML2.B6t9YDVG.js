import { A, e } from "./mermaid-parser.core.BjAFYe_e.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
