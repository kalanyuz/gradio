import { P, a } from "./mermaid-parser.core.BjAFYe_e.js";
export {
  P as PacketModule,
  a as createPacketServices
};
