import { G, f } from "./mermaid-parser.core.BjAFYe_e.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
