import { I, c } from "./mermaid-parser.core.BjAFYe_e.js";
export {
  I as InfoModule,
  c as createInfoServices
};
