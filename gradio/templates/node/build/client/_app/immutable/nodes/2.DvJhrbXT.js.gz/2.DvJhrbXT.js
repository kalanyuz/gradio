import { V, _ } from "../chunks/2.DR-_Vqz1.js";
export {
  V as component,
  _ as universal
};
